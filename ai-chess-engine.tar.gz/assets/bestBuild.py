# /// script
# dependencies = [
#   "chess",
# ]
# ///

import asyncio
import pygame
import chess
import random
import os

async def main():

    pygame.init()
    pygame.mixer.init()

    WIDTH = 480
    HEIGHT = 480
    SQUARE = WIDTH // 8

    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    pygame.display.set_caption("0rion | Press \"i\" for more info")

    # Load sound once
    move_sound = None
    try:
        move_sound = pygame.mixer.Sound("sounds/move.wav")
    except:
        pass

    board = chess.Board()
    clock = pygame.time.Clock()
    play_sound = False
    computer_thinking = False
    computer_move_time = 0
    COMPUTER_DELAY = 500  # milliseconds
    player_is_white = True
    show_info = False
    disable_show_info = False
    disable_switch = False
    global debug_message
    debug_message = ""

    # Promotion variables
    promotion_pending = False
    promotion_from = None
    promotion_to = None
    promotion_color = None



    # Load sound
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    move_sound = pygame.mixer.Sound(os.path.join(BASE_DIR, "sounds", "move.wav"))

    # Load piece images
    pieces = {}
    symbols = {
        "P": "wP", "N": "wN", "B": "wB", "R": "wR", "Q": "wQ", "K": "wK",
        "p": "bP", "n": "bN", "b": "bB", "r": "bR", "q": "bQ", "k": "bK",
    }

    for symbol, name in symbols.items():
        img = pygame.image.load(os.path.join(BASE_DIR, "images", f"{name}.png"))
        img = pygame.transform.scale(img, (SQUARE, SQUARE))
        pieces[symbol] = img

    selected_square = None

    def draw_board():
        colors = [(240, 217, 181), (181, 136, 99)]

        for rank in range(8):
            for file in range(8):

                draw_rank = rank
                draw_file = file

                if player_is_white is False:
                    draw_rank = 7 - rank
                    draw_file = 7 - file
                else:
                    draw_rank = rank
                    draw_file = file

                color = colors[(rank + file) % 2]

                pygame.draw.rect(
                    screen,
                    color,
                    pygame.Rect(
                        draw_file * SQUARE,
                        draw_rank * SQUARE,
                        SQUARE,
                        SQUARE
                    )
                )

    def draw_pieces():
        for square, piece in board.piece_map().items():
            file = chess.square_file(square)
            rank = chess.square_rank(square)

            if player_is_white is False:
                draw_file = 7 - file
                draw_rank = rank
            else:
                draw_file = file
                draw_rank = 7 - rank

            screen.blit(
                pieces[piece.symbol()],
                (draw_file * SQUARE, draw_rank * SQUARE)
            )

    def mouse_to_square(pos):
        file = pos[0] // SQUARE
        rank = pos[1] // SQUARE

        if player_is_white is False:
            file = 7 - file
            rank = 7 - rank

        return chess.square(file, 7 - rank)


    def draw_info_text():
        font = pygame.font.SysFont(None, 28)

        lines = [
            'Press "b" to play as Black'
        ]

        total_height = len(lines) * 40
        start_y = HEIGHT // 2 - total_height // 2

        for i, line in enumerate(lines):
            text = font.render(line, True, (0, 0, 0))
            x = WIDTH // 2 - text.get_width() // 2
            y = start_y + i * 40
            screen.blit(text, (x, y))

    def draw_promotion_menu(color):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))

        pieces_order = ["Q", "R", "B", "N"]
        if color == chess.BLACK:
            pieces_order = [p.lower() for p in pieces_order]

        start_x = WIDTH // 2 - (2 * SQUARE)
        y = HEIGHT // 2 - SQUARE // 2

        for i, p in enumerate(pieces_order):
            screen.blit(
                pieces[p],
                (start_x + i * SQUARE, y)
            )

    def draw_game_over(result):
        overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 180))
        screen.blit(overlay, (0, 0))
        
        if result == "win":
            title = "You Won!"
            color = (0, 255, 0)
        elif result == "loss":
            title = "You Lost."
            color = (255, 0, 0)
        else:
            title = "Draw"
            color = (255, 255, 0)
        
        title_font = pygame.font.SysFont(None, 72)
        title_text = title_font.render(title, True, color)
        title_rect = title_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 - 40))
        screen.blit(title_text, title_rect)
        
        instruction_font = pygame.font.SysFont(None, 36)
        instruction_text = instruction_font.render('Press "r" to play again', True, (255, 255, 255))
        instruction_rect = instruction_text.get_rect(center=(WIDTH // 2, HEIGHT // 2 + 40))
        screen.blit(instruction_text, instruction_rect)

    def is_higher_value_piece_attacked(board):
        """Check if any of our pieces is attacked by a lower-value piece"""
        piece_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
        }
        
        computer_color = board.turn
        
        
        for square in chess.SQUARES:
            piece = board.piece_at(square)
            
            # Check if it's our piece
            if piece and piece.color == computer_color:
                if piece.piece_type in [chess.KNIGHT, chess.BISHOP, chess.ROOK, chess.QUEEN]:
                    piece_value = piece_values.get(piece.piece_type, 0)
                    
                    # Check if opponent is attacking this square
                    attackers = list(board.attackers(not computer_color, square))
                    
                    if attackers:
                        
                        # Check if any attacker is lower value
                        for attacker_sq in attackers:
                            attacker_piece = board.piece_at(attacker_sq)
                            if attacker_piece:
                                attacker_value = piece_values.get(attacker_piece.piece_type, 0)
                                
                                
                                # If attacked by lower value piece, need to move
                                if attacker_value < piece_value:
                                    return square
        
        return None

    def find_safe_square_for_piece(board, piece_square):
        """Find a safe square to move an attacked piece"""
            
        for move in board.legal_moves:
            if move.from_square == piece_square:
                # Try this move
                board.push(move)
                
                # Is the piece still under attack here?
                # After push, turn has changed, so opponent is "board.turn" now
                still_attacked = len(list(board.attackers(board.turn, move.to_square))) > 0
                
                board.pop()
                
                
                # If not under attack, this is a safe square
                if not still_attacked:
                    return move
        
        return None
    
    def can_capture_attacking_piece(board, our_piece_square):
        """Check if we can capture the piece that's attacking our piece"""
        computer_color = board.turn
        
        # Find who is attacking our piece
        attackers = list(board.attackers(not computer_color, our_piece_square))
        
        for attacker_sq in attackers:
            # Can we capture this attacker?
            for move in board.legal_moves:
                if move.to_square == attacker_sq:
                    # Check if capturing is safe (they can't recapture)
                    board.push(move)
                    
                    can_recapture = any(
                        enemy_move.to_square == attacker_sq
                        for enemy_move in board.legal_moves
                    )
                    
                    board.pop()
                    
                    # If they can't recapture, this capture is good
                    if not can_recapture:
                        return move
        
        return None

    def would_hang_piece(board, move):
        """Check if making this move would hang a piece (the moved piece OR other pieces)"""
        piece_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
            chess.KING: 0
        }
        
        # Make the move temporarily
        board.push(move)
        
        opponent_color = board.turn
        our_color = not opponent_color
        
        hanging = False
        
        # Check ALL our pieces to see if any are now hanging
        for square in chess.SQUARES:
            piece = board.piece_at(square)
            
            if piece and piece.color == our_color:
                # Is this piece attacked?
                attackers = list(board.attackers(opponent_color, square))
                
                if len(attackers) > 0:
                    # It's attacked - is it defended?
                    defenders = list(board.attackers(our_color, square))
                    
                    if len(defenders) == 0:
                        # Attacked and undefended - hanging!
                        hanging = True
                        break
                    else:
                        # Defended - but can opponent win the exchange?
                        piece_value = piece_values[piece.piece_type]
                        
                        # Find lowest value attacker
                        min_attacker_value = 10
                        for attacker_sq in attackers:
                            attacker = board.piece_at(attacker_sq)
                            if attacker:
                                min_attacker_value = min(min_attacker_value, piece_values[attacker.piece_type])
                        
                        # If opponent can capture with lower value piece, it's bad
                        if min_attacker_value < piece_value:
                            hanging = True
                            break
        
        board.pop()
        return hanging
    
    def find_hanging_piece(board):
        """Find opponent pieces that can be captured for free"""
        piece_values = {
            chess.PAWN: 1,
            chess.KNIGHT: 3,
            chess.BISHOP: 3,
            chess.ROOK: 5,
            chess.QUEEN: 9,
        }
        
        best_capture = None
        best_value = 0
        
        for move in board.legal_moves:
            if board.is_capture(move):
                victim = board.piece_at(move.to_square)
                
                if victim:
                    # Make the capture
                    board.push(move)
                    
                    # Can opponent recapture?
                    can_recapture = any(
                        enemy_move.to_square == move.to_square
                        for enemy_move in board.legal_moves
                    )
                    
                    board.pop()
                    
                    # If they can't recapture, it's hanging!
                    if not can_recapture:
                        victim_value = piece_values.get(victim.piece_type, 0)
                        if victim_value > best_value:
                            best_value = victim_value
                            best_capture = move
        
        return best_capture
    
    def would_allow_opponent_mate(board, move):
        """Check if making this move would allow opponent to mate us in 1"""
        # Make our move
        board.push(move)
        
        # Now it's opponent's turn - can they mate us?
        opponent_can_mate = False
        
        for opp_move in board.legal_moves:
            board.push(opp_move)
            if board.is_checkmate():
                opponent_can_mate = True
                board.pop()
                break
            board.pop()
        
        board.pop()  # Undo our move
        return opponent_can_mate
    
    def can_opponent_checkmate(board):
        """Check if opponent has a checkmate in one move"""
        
        opponent_color = not board.turn
        
        # Check each of opponent's possible moves
        for move in board.legal_moves:
            # Make sure we're only looking at opponent's pieces
            piece = board.piece_at(move.from_square)
            if piece and piece.color == board.turn:
                # This is our piece, not opponent's - skip
                # We need to look at what opponent can do on THEIR turn
                pass
        
        # To check opponent's moves, we need to temporarily give them the turn
        board.turn = opponent_color
        
        has_mate = False
        for move in board.legal_moves:
            board.push(move)
            if board.is_checkmate():
                has_mate = True
                board.pop()
                break
            board.pop()
        
        # Restore our turn
        board.turn = not opponent_color
        
        return has_mate

    def find_move_to_prevent_mate(board):
        """Find a move that prevents opponent's checkmate in one"""
        
        legal_moves = list(board.legal_moves)
        
        for move in legal_moves:
            board.push(move)
            
            # Now it's opponent's turn - check if they can still mate
            opponent_color = board.turn
            
            # Look through all opponent's moves
            board.turn = opponent_color  # Should already be opponent's turn after push
            
            can_still_mate = False
            for opp_move in board.legal_moves:
                board.push(opp_move)
                if board.is_checkmate():
                    can_still_mate = True
                    board.pop()
                    break
                board.pop()
            
            board.pop()  # Undo our move
            
            # If opponent can't mate after this move, it's a good defense!
            if not can_still_mate:
                return move
        
        return None

    def get_safe_move(board):
        """Pick a move - prioritize saving valuable pieces and don't hang pieces"""
        
        # HIGHEST PRIORITY: Prevent checkmate in 1
        if can_opponent_checkmate(board):
            preventing_move = find_move_to_prevent_mate(board)
            if preventing_move:
                return preventing_move
        
        # FIRST PRIORITY: Check if any valuable piece is attacked by lower-value piece
        attacked_piece = is_higher_value_piece_attacked(board)
        if attacked_piece:
            # NEW: Before running away, check if we can just capture the attacker
            can_capture_attacker = can_capture_attacking_piece(board, attacked_piece)
            if can_capture_attacker and not would_allow_opponent_mate(board, can_capture_attacker):
                return can_capture_attacker
            
            # If can't capture attacker, move to safety
            safe_move = find_safe_square_for_piece(board, attacked_piece)
            if safe_move and not would_allow_opponent_mate(board, safe_move):
                return safe_move
        
        # SECOND PRIORITY: Capture hanging pieces
        hanging_capture = find_hanging_piece(board)
        if hanging_capture and not would_allow_opponent_mate(board, hanging_capture):
            return hanging_capture
        
        # THIRD PRIORITY: Filter out moves that would hang a piece OR allow opponent mate
        legal_moves = list(board.legal_moves)
        safe_moves = []
        
        for move in legal_moves:
            if not would_hang_piece(board, move) and not would_allow_opponent_mate(board, move):
                safe_moves.append(move)
        
        # If we have safe moves, pick one (prefer captures)
        if safe_moves:
            captures = [m for m in safe_moves if board.is_capture(m)]
            if captures:
                return random.choice(captures)
            return random.choice(safe_moves)
        
        # If no completely safe moves, at least avoid giving mate
        moves_no_mate = [m for m in legal_moves if not would_allow_opponent_mate(board, m)]
        if moves_no_mate:
            return random.choice(moves_no_mate)
        
        # If no choice, pick any legal move
        return random.choice(legal_moves)

    running = True

    while running:
        #Initialize/reset game state
        pygame.display.set_caption("0rion  | Press \"i\" for more info")
        board = chess.Board()
        selected_square = None
        play_sound = False
        computer_thinking = False
        computer_move_time = 0
        COMPUTER_DELAY = 500
        player_is_white = True
        show_info = False
        disable_show_info = False
        disable_switch = False
        promotion_pending = False
        promotion_from = None
        promotion_to = None
        promotion_color = None
        game_over = False
        game_result = None

        # Inner game loop
        game_running = True
        while game_running and running:
            clock.tick(60)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                    game_running = False

                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_r and game_over:
                        game_running = False  # Break inner loop to restart
                        break

                    if player_is_white is True:
                        if event.key == pygame.K_i and show_info == False and disable_show_info == False:
                            show_info = True
                        elif event.key == pygame.K_i and show_info == True:
                            show_info = False
                        if event.key == pygame.K_b and disable_switch == False:
                            player_is_white = False
                            show_info = False
                            pygame.display.set_caption("0rion")
                            disable_switch = True
                            computer_thinking = True
                            computer_move_time = pygame.time.get_ticks() + COMPUTER_DELAY

                # Human move

                # Promotion Selection
                if event.type == pygame.MOUSEBUTTONDOWN and promotion_pending:
                    mx, my = event.pos

                    start_x = WIDTH // 2 - (2 * SQUARE)
                    y = HEIGHT // 2 - SQUARE // 2

                    for i, piece_type in enumerate([chess.QUEEN, chess.ROOK, chess.BISHOP, chess.KNIGHT]):
                        rect = pygame.Rect(start_x + i * SQUARE, y, SQUARE, SQUARE)
                        if rect.collidepoint(mx, my):
                            move = chess.Move(
                                promotion_from,
                                promotion_to,
                                promotion=piece_type
                            )

                            if move in board.legal_moves:
                                board.push(move)
                                play_sound = True

                                computer_thinking = True
                                computer_move_time = pygame.time.get_ticks() + COMPUTER_DELAY

                            promotion_pending = False




                # Regular move
                if event.type == pygame.MOUSEBUTTONDOWN:
                    square = mouse_to_square(event.pos)
                    piece = board.piece_at(square)

                    # No piece selected yet → select if it's your piece
                    if selected_square is None:
                        if piece and piece.color == board.turn:
                            selected_square = square

                    else:
                        selected_piece = board.piece_at(selected_square)

                        # Clicked another own piece → switch selection
                        if piece and piece.color == board.turn:
                            selected_square = square

                        else:
                            move = chess.Move(selected_square, square)

                            # Pawn promotion check
                            if selected_piece and selected_piece.piece_type == chess.PAWN:
                                if (
                                    selected_piece.color == chess.WHITE
                                    and chess.square_rank(square) == 7
                                ) or (
                                    selected_piece.color == chess.BLACK
                                    and chess.square_rank(square) == 0
                                ):
                                    promotion_pending = True
                                    promotion_from = selected_square
                                    promotion_to = square
                                    promotion_color = selected_piece.color
                                    selected_square = None
                                    continue



                            if move in board.legal_moves:
                                board.push(move) #Causes the white pieces to move visually
                                
                                pygame.display.set_caption("0rion")
                                show_info = False #Turns off info text is it is displayed.
                                disable_show_info = True #Cannot look at info screen after the first move
                                disable_switch = True #Cannot switch colors after the first move
                                
                                play_sound = True

                                computer_thinking = True
                                computer_move_time = pygame.time.get_ticks() + COMPUTER_DELAY

                                # 🔴 CRITICAL: always reset
                                selected_square = None

                    

            # Computer move
            current_time = pygame.time.get_ticks()

            if (
                computer_thinking
                and board.turn != player_is_white
                and not board.is_game_over()
                and current_time >= computer_move_time
            ):
                move = get_safe_move(board)
                board.push(move)
                play_sound = True
                computer_thinking = False

            if board.is_game_over() and not game_over:
                game_over = True
                if board.is_checkmate():
                    if board.turn == player_is_white:
                        game_result = "loss"
                    else:
                        game_result = "win"
                else:
                    game_result = "draw"


            draw_board()

            if show_info:
                draw_info_text()

            draw_pieces()
            
            if promotion_pending:
                draw_promotion_menu(promotion_color)

            if game_over:
                draw_game_over(game_result)

            pygame.display.flip()

            if play_sound:
                move_sound.play()
                play_sound = False

            await asyncio.sleep(0)

        pygame.quit()

asyncio.run(main())