# Documentation #

# Note: 
Use this in terminal

git pull origin main --no-rebase
git push origin main

Using Pygame with Python

Got images for pieces.

Drew board.

User is able to move the images based on chess rules using 
chess library.

Computer makes random moves.

Added a sound after any move happens.

Made a delay so that the computer does not make a move
immediately after the user's move, it waits a little bit to
"think".

Changed promotion to auto-queen to any one of the four pieces:
Rook, Bishop, Knight or Queen. With selection screen.

Made an info text appear for switching colors, and it disappears
after the user moves or switches colors.

Disabled switching colors after the user makes the first move 
or switches to black.

Fixed piece selection to be more smooth. Before: the user would
like to select a piece and then select another piece and then
move the 2nd piece. But, this did not work because the 2nd
selection did not register. After: The most recent piece
selection can be moved.

Thought about changing code to JavaScript but I decided to use Pygbag
instead so I can use Pygame on the web. Pygbag is a tool that packages
Python projects into WebAssembly so they can run in a web browser!

I had to use the asynchio library for my code to work in the browser.
It gives control back to the browser's event loop when needed.

I needed this comment 

# /// script
# dependencies = [
#   "chess",
# ]
# ///

so that Pygbag will install the "chess" package.

Created the "requirements.txt" so that my piece images will load.

Uploaded my engine to github pages!

Note: I need to run "pygbag --ume_block 0 ." to prevent the "Ready to
Start!" text.

Need to put this in html before running "pygbag --ume_block 0 ." again:

<div id="note-text" style="position: absolute; left: 20px; top: 20px; background-color: rgba(211, 211, 211, 0.9); padding: 15px; border-radius: 5px; font-family: Arial, sans-serif;">
    <strong>Note:</strong><br>
    Press "i" for more info
</div>

* line 365

after </canvas> area.

    <script>
    var noteElement = document.getElementById('note-text');
    var isHidden = false;
    
    // Hide note on any key press or click (except 'r')
    document.addEventListener('keydown', function(e) {
        if (e.key === 'r' || e.key === 'R') {
            // Show the note again when 'r' is pressed
            noteElement.style.display = 'block';
            isHidden = false;
        } else if (!isHidden) {
            // Hide on any other key
            noteElement.style.display = 'none';
            isHidden = true;
        }
    });
    
    document.addEventListener('click', function() {
        if (!isHidden) {
            noteElement.style.display = 'none';
            isHidden = true;
        }
    });
    </script>

before </body> area

Actually, I can just hit a revert changes button in vs code!

Also, added info text for the html (gray background area).

Added game over, you won! and you lost. screens with play again function.

* Basic logic rules *

Tried using "minimax" algorithm but it seems a little too complicated
for what I want at the moment. I may use it later though.

I need to make sure each new improvement is not messing up previous 
improvements. So, I will check each one after each new improvement.

1. Random moves

2. Higher value piece runs away to safety if attacked by a lower value
piece.

3. Don't hang pieces((don't move a piece to where it can be captured for 
freeand don't make a move that will still leave another piece hanging).

4. If the user can checkmate on the next turn then the computer needs to
make a move to prevent that from happening.

5. If the computer can make a move so that on the next turn the user
is able to checkmate then the computer needs to not make that move.

6. If I attack a piece and that piece moves but I get mate in 1 then that
piece should not have moved (mate in 1 has higher priority)

7. If I am hanging a piece then the computer should take it.

8. If I attack a piece with a higher value but my attacker is 
hanging then the computer should take my hanging piece.

9. If I attack a piece that is the same value but it is hanging then
the computer should take it: yes, already taken care of.

10. If I have mate in 1 on the next turn but the computer can take my
hanging piece to prevent mate in 1 then the computer should take my
hanging piece.

11. Okay, I am going to have to create a custom screen so I can debug
correctly.... Okay, did that. Debugging will much easier now 
(I can create custom chess positions)

12. When I attack a piece of lower value the computer will take my 
piece of higher value even if I am protected if the computer wins the
exchange (gets more point value out of the exchange)

13. When I attack a piece of higher value and my piece is defended
the lower value piece does takes my attacker cuz it would win the
exchange.

14. Will perform a mate in 1 if available.

15. Avoids bad trade by checking future captures -> this took a while.
Only looks into 1 or 2 moves into the future though?

16. The computer will sometimes make a move to prevent checkmate but
it will be the worst move instead of the best move.

17. When I have a hanging piece, the computer will take it. 
HOWEVER, it should not take it if the computer's attack reveals
a hanging piece that I can take so that I win material.

18. Fixed the sound problem caused by Pygbag by loading the \
sound on a fresh frame cycle every time at the beginning of the
loop.

In Progress

18. Computer needs to recognize skewers and how to avoid them.